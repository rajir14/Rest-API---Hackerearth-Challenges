default_app_config = 'rest_framework.authtoken.apps.AuthTokenConfig'
